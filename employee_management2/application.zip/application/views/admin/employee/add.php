<script src="//cdn.jsdelivr.net/webshim/1.14.5/polyfiller.js"></script>
<script>
webshims.setOptions('forms-ext', {types: 'date'});
webshims.polyfill('forms forms-ext');
</script>
<!--company Modal-->

<div id="comModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="comModalLabel" aria-hidden="true">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h3 id="comModalLabel">Add a New Company</h3>
</div>
<?php
    //flash messages
    if (isset($flash_message)) {
        if ($flash_message == TRUE) {
            echo '<div class="alert alert-success">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Well done!</strong> new company created with success.';
            echo '</div>';
        } else {
            echo '<div class="alert alert-error">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
            echo '</div>';
        }
    }
    ?>

    <?php
    //form data
    $attributes = array('class' => 'form-horizontal', 'id' => '');

    //form validation
    echo validation_errors();

    echo form_open_multipart('admin/company/add', $attributes);
?>
<div class="modal-body">

    <fieldset>
        <div class="control-group">
            <label for="inputError" class="control-label">Name</label>
            <div class="controls">
                <input type="text" id="" name="name" value="<?php echo set_value('name'); ?>" >
                <!--<span class="help-inline">Woohoo!</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Upload Logo</label>
            <div class="controls">
                <input type="file" id="" name="company_logo" >
                <!--<span class="help-inline">Woohoo!</span>-->
            </div>
        </div>
    </fieldset>
</div>
<div class="modal-footer">
    <input type="hidden" name="com_confirm" value="com_confirm">
<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
<button class="btn btn-primary" type="submit">Save</button>
</div>
<?php echo form_close(); ?>
</div>

<!--company Modal End-->

<!--Department Modal-->

<div id="depModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="depModalLabel" aria-hidden="true">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h3 id="depModalLabel">Add a New Department</h3>
</div>
<?php
    //flash messages
    if (isset($flash_message)) {
        if ($flash_message == TRUE) {
            echo '<div class="alert alert-success">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Well done!</strong> new department added with success.';
            echo '</div>';
        } else {
            echo '<div class="alert alert-error">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
            echo '</div>';
        }
    }
    ?>

    <?php
    //form data
    $attributes = array('class' => 'form-horizontal', 'id' => '');
    $options_company = array('' => "Select");
    foreach ($company as $row) {
        $options_company[$row['id']] = $row['name'];
    }

    //form validation
    echo validation_errors();

    echo form_open('admin/department/add', $attributes);
?>
<div class="modal-body">
    <fieldset>
        <div class="control-group">
            <label for="company_id" class="control-label">Company</label>
            <div class="controls">
                <?php //echo form_dropdown('department_id', $options_department, '', 'class="span2"');

                 echo form_dropdown('company_id', $options_company, set_value('company_id'), 'class="span2"'); ?>

            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Name</label>
            <div class="controls">
                <input type="text" id="" name="name" value="<?php echo set_value('name'); ?>" >
                <!--<span class="help-inline">Woohoo!</span>-->
            </div>
        </div>
    </fieldset>
</div>
<div class="modal-footer">
    <input type="hidden" name="dep_confirm" value="dep_confirm">
<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
<button class="btn btn-primary" type="submit">Save</button>
</div>
<?php echo form_close(); ?>

</div>

<!--Department Modal End-->

<div class="container top">

    <ul class="breadcrumb">
        <li>
            <a href="<?php echo site_url("admin"); ?>">
                <?php echo ucfirst($this->uri->segment(1)); ?>
            </a> 
            <span class="divider">/</span>
        </li>
        <li>
            <a href="<?php echo site_url("admin") . '/' . $this->uri->segment(2); ?>">
                <?php echo ucfirst($this->uri->segment(2)); ?>
            </a> 
            <span class="divider">/</span>
        </li>
        <li class="active">
            <a href="#">New</a>
        </li>
    </ul>

    <div class="page-header">
        <h2>
            Adding <?php echo ucfirst($this->uri->segment(2)); ?>
        </h2>
    </div>

    <?php
    //flash messages
    if (isset($flash_message)) {
        if ($flash_message == TRUE) {
            echo '<div class="alert alert-success">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Well done!</strong> new employee added with success.';
            echo '</div>';
        } else {
            echo '<div class="alert alert-error">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
            echo '</div>';
        }
    }
    ?>

    <?php
    //form data
    $attributes = array('class' => 'form-horizontal', 'id' => '');
    $options_department = array('' => "Select");
    $options_company = array('' => "Select");
    foreach ($department as $row) {
        $options_department[$row['id']] = $row['name'];
    }
    foreach ($company as $val) {
        $options_company[$val['id']] = $val['name'];
    }

    //form validation
    echo validation_errors();

    echo form_open_multipart('admin/employee/add', $attributes);
    ?>
    
        <div class="control-group">
            <label for="company_id" class="control-label">Select Company</label>
            <div class="controls">
                <?php echo form_dropdown('company_id', $options_company, set_value('company_id'), 'class="span2"'); ?>
                <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#comModal">Add</button>
            </div>
        </div>
        <div class="control-group">
            <label for="department_id" class="control-label">Select Department</label>
            <div class="controls">
                <?php echo form_dropdown('department_id', $options_department, set_value('department_id'), 'class="span2"'); ?>
                <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#depModal">Add</button>
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Upload Photo</label>
            <div class="controls">
                <input type="file" id="" name="employee_pic">
                <!--<span class="help-inline">Woohoo!</span>-->
            </div>
        </div>
    <ul class="nav nav-tabs" id="myTab">
        <li class="active"><a href="#personal_info">Personal Information</a></li>
        <li><a href="#service_info">Profile</a></li>
        <li><a href="#messages">Messages</a></li>
        <li><a href="#settings">Settings</a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active" id="personal_info">
            <fieldset>
                <div class="control-group">
                    <label for="inputError" class="control-label">Father's name</label>
                    <div class="controls">
                        <input type="text" id="" name="father_name" value="<?php echo set_value('father_name'); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label for="inputError" class="control-label">Father's contact no.</label>
                    <div class="controls">
                        <input type="text" id="" name="father_contact" value="<?php echo set_value('father_contact'); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label for="inputError" class="control-label">Mother's name</label>
                    <div class="controls">
                        <input type="text" id="" name="mother_name" value="<?php echo set_value('Mother_name'); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label for="inputError" class="control-label">Date of Birth</label>
                    <div class="controls">
                        <input type="date" id="" name="d_o_b" value="<?php echo set_value('d_o_b'); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label for="inputError" class="control-label">Present Age</label>
                    <div class="controls">
                        <input type="text" id="" name="present_age" value="<?php echo set_value('present_age'); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label for="inputError" class="control-label">Blood Group</label>
                    <div class="controls">
                        <select id="" name="blood_group">
                            <option value="A+">A+</option>
                            <option value="B+">B+</option>
                            <option value="O+">O+</option>
                            <option value="A-">A-</option>
                            <option value="B-">B-</option>
                            <option value="O-">O-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                        </select>
                    </div>
                </div>
                <div class="control-group">
                    <label for="inputError" class="control-label">Voter ID no.</label>
                    <div class="controls">
                        <input type="text" id="" name="voter_id" value="<?php echo set_value('voter_id'); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label for="inputError" class="control-label">Permanent address</label>
                    <div class="controls">
                        <input type="text" id="" name="permanent_address" value="<?php echo set_value('permanent_address'); ?>">
                        <!--<span class="help-inline">Cost Price</span>-->
                    </div>
                </div>
                <div class="control-group">
                    <label for="inputError" class="control-label">Present address</label>
                    <div class="controls">
                        <input type="text" id="" name="present_address" value="<?php echo set_value('present_address'); ?>">
                    </div>
                </div>
            </fieldset>
        </div>
        <div class="tab-pane" id="service_info">
            
        </div>
        <div class="tab-pane" id="messages">...</div>
        <div class="tab-pane" id="settings">...</div>
    </div>
    <fieldset>
        <div class="control-group">
            <label for="inputError" class="control-label">ID No.</label>
            <div class="controls">
                <input type="text" id="" name="id_no" value="<?php echo set_value('id_no'); ?>">
                <!--<span class="help-inline">Woohoo!</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Name</label>
            <div class="controls">
                <input type="text" id="" name="employee_name" value="<?php echo set_value('employee_name'); ?>">
                <!--<span class="help-inline">Woohoo!</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Designation</label>
            <div class="controls">
                <input type="text" id="" name="designation" value="<?php echo set_value('designation'); ?>" >
                <!--<span class="help-inline">Woohoo!</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Qualification</label>
            <div class="controls">
                <input type="text" id="" name="qualification" value="<?php echo set_value('qualification'); ?>">
                <!--<span class="help-inline">Cost Price</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Experience (If any)</label>
            <div class="controls">
                <input type="text" id="" name="experience" value="<?php echo set_value('experience'); ?>">
                <!--<span class="help-inline">Cost Price</span>-->
            </div>
        </div>  
        <div class="control-group">
            <label for="inputError" class="control-label">Last Employer (If any)</label>
            <div class="controls">
                <input type="text" id="" name="last_employer" value="<?php echo set_value('last_employer'); ?>">
                <!--<span class="help-inline">Cost Price</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Joining Date</label>
            <div class="controls">
                <input type="date" name="joining_date" value="<?php echo set_value('joining_date'); ?>">
                <!--<span class="help-inline">OOps</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Confirmation Date</label>
            <div class="controls">
                <input type="date" name="confirmation_date" value="<?php echo set_value('confirmation_date'); ?>">
                <!--<span class="help-inline">OOps</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Place of work</label>
            <div class="controls">
                <input type="text" id="" name="place_of_work" value="<?php echo set_value('place_of_work'); ?>">
                <!--<span class="help-inline">Cost Price</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Present salary</label>
            <div class="controls">
                <input type="text" id="" name="present_salary" value="<?php echo set_value('present_salary'); ?>">
                <!--<span class="help-inline">Cost Price</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Last Increment Date</label>
            <div class="controls">
                <input type="date" name="last_increment_date" value="<?php echo set_value('last_increment_date'); ?>">
                <!--<span class="help-inline">OOps</span>-->
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Contact Number</label>
            <div class="controls">
                <input type="text" id="" name="contact_number" value="<?php echo set_value('contact_number'); ?>">
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Surety bond given</label>
            <div class="controls">
                <label class="radio inline"><input type="radio" name="bond_given" value="yes"> Yes</label>
                <label class="radio inline"><input type="radio" name="bond_given" value="no"> No</label>
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Name of the guarantor</label>
            <div class="controls">
                <input type="text" id="" name="guarantor" value="<?php echo set_value('guarantor'); ?>">
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Relation with guarantor</label>
            <div class="controls">
                <input type="text" id="" name="relation_guarantor" value="<?php echo set_value('relation_guarantor'); ?>">
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Mobile No. of guarantor</label>
            <div class="controls">
                <input type="text" id="" name="mobile_guarantor" value="<?php echo set_value('mobile_guarantor'); ?>">
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Name of spouse</label>
            <div class="controls">
                <input type="text" id="" name="spouse" value="<?php echo set_value('spouse'); ?>">
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Contact No. of spouse</label>
            <div class="controls">
                <input type="text" id="" name="contact_spouse" value="<?php echo set_value('contact_spouse'); ?>">
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">No. of children(s)</label>
            <div class="controls">
                <input type="number" id="" name="children" value="<?php echo set_value('children'); ?>">
            </div>
        </div>
        
        <div class="form-actions">
            <button class="btn btn-primary" type="submit" onclick="history.go(-1);return true;">Save changes</button>
            <button class="btn" type="reset">Cancel</button>
        </div>
    </fieldset>

    <?php echo form_close(); ?>

</div>
